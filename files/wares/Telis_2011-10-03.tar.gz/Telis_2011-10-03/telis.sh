#!/bin/bash
maquinaTelis=maquinaTelis_2011-10-03.jar
javaVersion=`java -version 2>&1 | head -n 1`
msgDeErro="Opção inválida, abortando..."
paginaDeAjuda="isite 'http://twiki.edugraf.ufsc.br/bin/view/Telis/InstalandoTelis' para maiores informações sobre a instalação."
erroDeJava="Não foi encontrado nenhum diretório java, v$paginaDeAjuda"

function detectarDiretorioTelis() {
	if [ `echo ${0} | cut -b1` == '.'  ]; then
		dir=`pwd``/usr/bin/dirname "$0" | cut -b2-`
	
		elif [ `echo ${0} | cut -b1` == '/' ]; then
		dir=`/usr/bin/dirname "$0"`
	
        	else dir=`pwd`/`/usr/bin/dirname "$0"`
	fi
	
	cd "${dir}"
}

function iniciarAmbienteTelis() {
	echo "Ambiente Telis"
	
	detectarDiretorioTelis
		
	if [ "$JAVA_HOME" == "" ]; then
		java -Djava.library.path=./bib/ -cp bib/$maquinaTelis:bib/tabSplitter.jar:bib/com.noelios.restlet.jar:bib/com.noelios.restlet.ext.net.jar:bib/org.restlet.jar:bib/ br.ufsc.edugraf.telis.Ambiente
		
		
		else $JAVA_HOME/bin/java -Djava.library.path=./bib -cp bib/$maquinaTelis:bib/tabSplitter.jar:bib/com.noelios.restlet.jar:bib/com.noelios.restlet.ext.net.jar:bib/org.restlet.jar:bib/ br.ufsc.edugraf.telis.Ambiente
	fi
	
	exit
}

if [ "$JAVA_HOME" == "" ]; then
	
	if [ "`echo $javaVersion | cut -b -4`" != "java" ]; then
		
		echo "Variável de ambiente JAVA_HOME não encontrada. Deseja fazer uma varredura rápida para encontrá-la?[y/n]"
		read RESPOSTA
		
		case $RESPOSTA in
			n) echo "V$paginaDeAjuda" && exit;;
			y) break;;
			*) echo $msgDeErro && exit;;
		esac
		
		for NOME in `locate /bin/java | grep java$`
		do
			JAVA_HOME=`dirname $NOME`
			JAVA_HOME=`dirname $JAVA_HOME`
		done
		
		if [ "$JAVA_HOME" == "" ]; then
			
			echo "A busca rápida não foi capaz de encontrar o diretório java. Deseja fazer uma varredura mais lenta para encontrá-lo? [y/n]"
			read RESPOSTA
		
			case $RESPOSTA in
				n) echo "V$paginaDeAjuda" && exit;;
				y) break;;
				*) echo $msgDeErro && exit;;
			esac
			
			cd /
			for NOME in `find . 2> /dev/null | grep bin/java$`
			do
				JAVA_HOME=`dirname $NOME`
				JAVA_HOME=`dirname $JAVA_HOME`
			done

			JAVA_HOME=`echo $JAVA_HOME | cut -c 2-`
			
			if [ "$JAVA_HOME" == "" ]; then
				echo "$erroDeJava"
				exit
			fi
			
		fi
		
		else iniciarAmbienteTelis
	fi
fi

iniciarAmbienteTelis
