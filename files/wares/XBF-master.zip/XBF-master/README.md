# XBF


XBF - eXtensible BrainFuck - differs from classical brainfuck in various ways

brainfuck: https://esolangs.org/wiki/Brainfuck

This project is currently abandoned.
