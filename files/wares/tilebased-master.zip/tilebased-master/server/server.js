//var express = require('express');
var app = require('http').createServer(handler)
var io = require('socket.io')(app);
var fs = require('fs');
app.listen(process.env.PORT || 8080);

var env = process.env.NODE_ENV || 'dev';

var state = JSON.parse(fs.readFileSync(__dirname + '/map.json', 'utf8'));
var map = state.map;
var width = state.width;
var height = state.height;


function handler (req, res) {
  fs.readFile(__dirname + '/index.html',
  function (err, data) {
    if (err) {
      res.writeHead(500);
      return res.end('Error loading index.html');
    }

    res.writeHead(200);
    res.end(data);
  });
}

io.on('connection', function (socket) {
  socket.emit('state', { state: state });
  socket.on('my other event', function (data) {
    console.log(data);
  });
});

